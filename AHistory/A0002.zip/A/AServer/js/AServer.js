﻿var aHTTPServer = require("./js/AHTTPServer");

aHTTPServer.startAHTTPServer();