﻿window.onload = function(){
    window.location.href = "http://localhost:8888";
}